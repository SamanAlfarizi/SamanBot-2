</p>
<p align="center">
<a href="https://repository-images.githubusercontent.com/292765152/b5b54c80-ef19-11ea-9998-10a88f042830"><img title="AGUS BOT" src="https://repository-images.githubusercontent.com/292765152/b5b54c80-ef19-11ea-9998-10a88f042830"></a>
<p align="center">
<a href="https://github.com/AgusAliansyah?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/AgusAliansyah?color=blue&style=flat-square"></a>
<a href="https://github.com/AgusAliansyah/vvipbot-wa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/AgusAliansyah/vvipbot-wa?color=red&style=flat-square"></a>
<a href="https://github.com/AgusAliansyah/vvipbot-wa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/AgusAliansyah/vvipbot-wa?color=red&style=flat-square"></a>
<a href="https://github.com/AgusAliansyah/termux-whatsapp-bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/AgusAliansyah/vvipbot-walabel=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FAgusAliansyah%2Fvvipbot-wa&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="#"><img title="MAINTENED" src="https://img.shields.io/badge/MAINTENED-YES-blue.svg"></a>
</p>

<div align="center">
   <a href="https://repository-images.githubusercontent.com/292765152/b5b54c80-ef19-11ea-9998-10a88f042830"> "AGUS BOT" <a href="https://imgbb.com/"><img src="https://i.ibb.co/HNvqY6F/vvipindo-bot.jpg" alt="vvipindo-bot" border="0"></a>
    <h3> SCRIPT MODIFIKASI BUKAN HASIL SENDIRI </h3>

# Hai 👋🏻

Re-upload numpang ganti nama gabakal bikin lu pro
</div>


## Give me Start ⭐ please

## Alat

Download aplikasi termux disini [DOWNLOAD](https://play.google.com/store/apps/details?id=com.termux) 


## Settings

* Nama bot
* Instagram
* Kapan Bot aktif
* Apikey mhankbarbar
* Apikey vhtear
* Kontak whatsapp owner

Custom di sini [SETTING](https://github.com/AgusAliansyah/vvipbot-wa/blob/master/index.js/#L13)


## Penginstalan

Jika pertama kali membuka termux lakukan perintah berikut :
```bash
> pkg install git
> pkg install wget
> pkg install ffmpeg
> pkg install nodejs
> pkg install npm
```
Lalu clone repo
```bash
> git clone https://github.com/AgusAliansyah/vvipbot-wa
> cd vvipbot-wa
```
Lanjutkan dengan
```bash
> bash install.sh
```
Jika mengalami error, lakukan perintah manual berikut :
```bash
> pkg install tesseract
> npm i -g cwebp
> npm i -g ytdl
> npm i node-tesseract-ocr
> npm i
> npm i got
```
Jalankan bot
```bash
> node index.js
```
Terakhir scan kode QR



## FITUR

| SIMSIMI |❌|
| ------------- | ------------- |
| Simsimi |❌|

| FUN |Yes|
| ------------- | ------------- |
| Say|✅|
| Nama ninja|❌|
| Puisi|✅|
| Cerpen|✅|
| Tagme|✅|
| Seberapa gay|✅|
| Seberapa bucin|✅|
| Chat prank|✔|
| Font alay|✅|
| Family 100|✅|
| Kata kata receh|✅|
| Status bapack|✅|
| Gombal|✅|
|BUCIN|✅|


| PRIMBON |Yes|
| ------------- | ------------- |
| Arti nama|✅|
| Kecocokan nama|✅|
| Get zodiak|✅|
| Zodiak|❌|

| Game |✅|
| ------------- | ------------- |
| Tebak gambar|✅|
| Family 100|❌|
| Truth or dare|✅|
| Kerang ajaib (apakah, bolehkah, kapan)|✅|


| DOWNLOAD |Yes|
| ------------- | ------------- |
| Youtube Music |✅|
| Youtube Video |✅|
| Instagram foto/video |✅|
| Facebook video |✅|
| Twitter video |✅|

| TOOLS |Yes|
| ------------- | ------------- |
| Nulis|❌|
| Stiker|✅|
| OCR|✅|
| Instagram stalker|✅|
| Shortlink|✅|

| PICTURE |Yes|
| ------------- | ------------- |
| Cecan|✅|
| Cogan|✅|
| Anime|✅|
| Loli|✅|
| Neko|✅|
| Wallpaper|✅|
| Quotes|✅|
| Twitter|✅|
| Meme|✅|
| Img|✅|

| TEXT |Yes|
| ------------- | ------------- |
| Quotes maker|✅|
| Logo pornhub|✅|
| Logo e-sport|❌|

| EDUKASI |Yes|
| ------------- | ------------- |
| Al-Qur'an|✅|
| Al-Qur'an per surah|✅|
| Brainly|✅|
| Wikipedia|✅|
| Fakta|✅|
| KBBI|✅|
| Tanggal Nasional|✅|

| WHEATER |Yes|
| ------------- | ------------- |
| Info BMKG |✅|
| Info gempa |✅|
| Info cuaca |✅|

| Others |Yes|
| ------------- | ------------- |
| Jadwal tv|✅|
| Jadwal tv (channel)|✅|
| Jadwal sholat|✅|
| Info Covid|✅|
| Info anime|✅|
| Lirik lagu|✅|
| Chord lagu|✅|
| Mini map|✅|

| Groups |Yes|
| ------------- | ------------- |
| Merubah Nama grup|✅|
| Merubah deskripsi grup|✅|
| Menutup grup|✅|
| Membuka grup|✅|
| Ping|✅|
| Owner|✅|

## Contacts
* [Instagram](https://www.instagram.com/agus.alnsyh71)
* My whatsapp [Agus Aliansyah](https://wa.me/6289613469459)


## Terimakasih untuk
* [`Fdciabdul`](https://github.com/fdciabdul)
* [`mrfzvx12`](https://github.com/mrfzvx12)
* [`Aruga`](https://github.com/ArugaZ)
* [`Mhankbarbar`](https://github.com/MhankBarBar)
* [`Alfiansx`](https://github.com/alfiansx)
* [`Bintang73`](https://github.com/Bintang73)
* [`Adiwajshing`](https://github.com/adiwajshing/Baileys)
